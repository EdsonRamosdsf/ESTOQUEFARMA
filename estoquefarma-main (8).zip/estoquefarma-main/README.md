## Modulos necessários para o venv
* Django
* asgiref
* djangorestframework
* pip
* pytz
* setuptools
* sqlparse